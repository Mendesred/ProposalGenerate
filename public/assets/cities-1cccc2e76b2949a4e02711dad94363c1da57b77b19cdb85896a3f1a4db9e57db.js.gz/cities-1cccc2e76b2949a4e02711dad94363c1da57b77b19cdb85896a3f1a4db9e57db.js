(function() {
  jQuery(function() {
    return $('#cityTab').DataTable({
      responsive: true
    });
  });

}).call(this);
