(function() {
  jQuery(function() {
    return $('#equipamentTab').DataTable({
      responsive: true
    });
  });

}).call(this);
