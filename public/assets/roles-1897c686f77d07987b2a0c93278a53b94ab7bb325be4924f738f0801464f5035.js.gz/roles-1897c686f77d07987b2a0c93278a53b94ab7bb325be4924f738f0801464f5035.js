(function() {
  jQuery(function() {
    return $('#roleTab').DataTable({
      responsive: true
    });
  });

}).call(this);
